Arduino Cloud historic data

variables:
  - id: 349ae934-6412-4591-82b2-7b0714a47475
    name: sensor1eC
    thingName: SinkholeBSN
  - id: 46728c18-dd57-4a39-9fcd-7c496ddbb811
    name: sensor1LatesteCAvg
    thingName: SinkholeBSN
  - id: 172358ee-d129-4dfa-bcd9-7eb02e5cdf20
    name: sensor1LatestMoistureAvg
    thingName: SinkholeBSN
  - id: 7868c6f0-2eb5-4e5b-bdcb-6fcebfd0eabf
    name: sensor1LatestpHAvg
    thingName: SinkholeBSN
  - id: 1392dd06-744a-4a04-a98c-2bd02c86ee12
    name: eCFlag
    thingName: SinkholeBSN
  - id: 1575d513-5d01-49f2-9e37-b1ee59d08f79
    name: gyroscopeFlag
    thingName: SinkholeBSN
  - id: 5361868e-1f3e-4798-a1fe-9368857bd158
    name: soilMoistureFlag
    thingName: SinkholeBSN
  - id: 35ca91f2-caae-42fe-a0ab-302321945a02
    name: sensor1pH
    thingName: SinkholeBSN
  - id: a1bdfd21-c638-4be5-a05a-4c6ce3328465
    name: pHFlag
    thingName: SinkholeBSN
  - id: 2e04047e-4bed-4dfb-8d5f-3e338508db24
    name: sensor1Pitch
    thingName: SinkholeBSN
  - id: 522b2cdc-ddbe-48f5-bf51-f2eb7eed5340
    name: sensor1Roll
    thingName: SinkholeBSN
  - id: 73a4ace1-cdaa-48f7-a00d-91c45ce1619c
    name: sinkHole
    thingName: SinkholeBSN
  - id: 1ad9321d-2d55-439d-a807-a53798965c90
    name: sensor1MoisturePercentage
    thingName: SinkholeBSN
  - id: 673e47af-0cfb-41bd-8bc0-bad3ceaf3706
    name: sensor1Yaw
    thingName: SinkholeBSN
  - id: c7c8ad5e-83ae-47e5-a8dc-359163675a08
    name: sensor1LatestPitchAvg
    thingName: SinkholeBSN
  - id: ed282094-fe4d-4107-a968-8810decff7c3
    name: sensor1LatestRollAvg
    thingName: SinkholeBSN
  - id: 7f8fd858-d6c7-4549-8911-be67903df3bd
    name: sensor1LatestYawAvg
    thingName: SinkholeBSN
from: 2025-07-03T00:00:00Z
to: 2025-07-04T23:59:59Z

Have fun! :)
